## Requisitos para compilar ##
- Para compilar el proyecto se requiere NVIDIA Toolkit version12, si no lo tenéis, instalenlo
    y extrayen el archivo .cu y .h (si el NVIDIA Toolkit cambia de versión)
- Tener "Test.for"

## ¿Cómo compilar y ejecutar? ##
Después de los requisitos, aseguren de tener el Debug x64 para poder compilar. Cuando compiléis
  el programa, se creará un programa .exe, donde deberéis entrar y ejecutar con:
  "Cuda.exe test.for 1000", el orden es, ejecutable, archivo .for y los números de iterancias.
